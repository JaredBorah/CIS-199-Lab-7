﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CalcBtn = new System.Windows.Forms.Button();
            this.futureLbl = new System.Windows.Forms.Label();
            this.interestRateLbl = new System.Windows.Forms.Label();
            this.yearsLbl = new System.Windows.Forms.Label();
            this.finalValue = new System.Windows.Forms.Label();
            this.presentOutPut = new System.Windows.Forms.Label();
            this.futureTxt = new System.Windows.Forms.TextBox();
            this.interestRateTxt = new System.Windows.Forms.TextBox();
            this.yearTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(312, 239);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(99, 23);
            this.CalcBtn.TabIndex = 0;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // futureLbl
            // 
            this.futureLbl.AutoSize = true;
            this.futureLbl.Location = new System.Drawing.Point(262, 47);
            this.futureLbl.Name = "futureLbl";
            this.futureLbl.Size = new System.Drawing.Size(93, 17);
            this.futureLbl.TabIndex = 1;
            this.futureLbl.Text = "Future Value:";
            // 
            // interestRateLbl
            // 
            this.interestRateLbl.AutoSize = true;
            this.interestRateLbl.Location = new System.Drawing.Point(210, 90);
            this.interestRateLbl.Name = "interestRateLbl";
            this.interestRateLbl.Size = new System.Drawing.Size(145, 17);
            this.interestRateLbl.TabIndex = 2;
            this.interestRateLbl.Text = "Annual Interest Rate: ";
            // 
            // yearsLbl
            // 
            this.yearsLbl.AutoSize = true;
            this.yearsLbl.Location = new System.Drawing.Point(271, 133);
            this.yearsLbl.Name = "yearsLbl";
            this.yearsLbl.Size = new System.Drawing.Size(84, 17);
            this.yearsLbl.TabIndex = 3;
            this.yearsLbl.Text = "No. of Year:";
            // 
            // finalValue
            // 
            this.finalValue.AutoSize = true;
            this.finalValue.Location = new System.Drawing.Point(254, 190);
            this.finalValue.Name = "finalValue";
            this.finalValue.Size = new System.Drawing.Size(101, 17);
            this.finalValue.TabIndex = 4;
            this.finalValue.Text = "Present Value:";
            // 
            // presentOutPut
            // 
            this.presentOutPut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presentOutPut.Location = new System.Drawing.Point(361, 189);
            this.presentOutPut.Name = "presentOutPut";
            this.presentOutPut.Size = new System.Drawing.Size(131, 24);
            this.presentOutPut.TabIndex = 5;
            this.presentOutPut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // futureTxt
            // 
            this.futureTxt.Location = new System.Drawing.Point(361, 44);
            this.futureTxt.Name = "futureTxt";
            this.futureTxt.Size = new System.Drawing.Size(131, 22);
            this.futureTxt.TabIndex = 6;
            this.futureTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // interestRateTxt
            // 
            this.interestRateTxt.Location = new System.Drawing.Point(361, 87);
            this.interestRateTxt.Name = "interestRateTxt";
            this.interestRateTxt.Size = new System.Drawing.Size(131, 22);
            this.interestRateTxt.TabIndex = 7;
            this.interestRateTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // yearTxt
            // 
            this.yearTxt.Location = new System.Drawing.Point(361, 130);
            this.yearTxt.Name = "yearTxt";
            this.yearTxt.Size = new System.Drawing.Size(131, 22);
            this.yearTxt.TabIndex = 8;
            this.yearTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Lab7
            // 
            this.AcceptButton = this.CalcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.yearTxt);
            this.Controls.Add(this.interestRateTxt);
            this.Controls.Add(this.futureTxt);
            this.Controls.Add(this.presentOutPut);
            this.Controls.Add(this.finalValue);
            this.Controls.Add(this.yearsLbl);
            this.Controls.Add(this.interestRateLbl);
            this.Controls.Add(this.futureLbl);
            this.Controls.Add(this.CalcBtn);
            this.Name = "Lab7";
            this.Text = "Lab 7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CalcBtn;
        private System.Windows.Forms.Label futureLbl;
        private System.Windows.Forms.Label interestRateLbl;
        private System.Windows.Forms.Label yearsLbl;
        private System.Windows.Forms.Label finalValue;
        private System.Windows.Forms.Label presentOutPut;
        private System.Windows.Forms.TextBox futureTxt;
        private System.Windows.Forms.TextBox interestRateTxt;
        private System.Windows.Forms.TextBox yearTxt;
    }
}

