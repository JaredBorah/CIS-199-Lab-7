﻿//C5608
//Due Date: 11/11/2018
//Lab 7
//CIS199-75
//This lab shows how to take a future value with a certain interest rate, number of years, and show its present value
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        

        public Lab7()
        {
            InitializeComponent();
        }


        // Precondition:  calcBtn has been clicked
        // Postcondition: if input is valid, present value is calculated
        //                else error message is displayed
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            double presentValue;//This is my present value variable
            double futureValue;//This is my future value variable
            double annualInterestRate;//This is my interest rate variable
            int numYears;//This is my number of years variable

            if (double.TryParse(futureTxt.Text, out futureValue) && futureValue >= 0)//This tries to parse the future value
            {
                if (double.TryParse(interestRateTxt.Text, out annualInterestRate) && annualInterestRate > 0)//This tries to parse the interest rate
                {
                    if (int.TryParse(yearTxt.Text, out numYears) && numYears > 0)//This tries to parse the number of years
                    {
                        presentValue = CalcPresentValue(futureValue, annualInterestRate, numYears);
                        presentOutPut.Text = presentValue.ToString("C");//This displays the present value
                    }
                    else
                        MessageBox.Show("Enter Valid Years!");

                }
                else
                    MessageBox.Show("Enter Valid Interest Rate!");

            }
            else
                MessageBox.Show("Enter Valid Future Value!");

            

        }


        // Precondition:  futureVal >= 0, rate > 0, years > 0
        // Postcondition: Present value needed is returned
        private double CalcPresentValue(double futureValue, double annualInterestRate, int numYears)//This is my value returning method
        {
            double presentValue; // Calculated present value

            presentValue = (futureValue / Math.Pow(1 + annualInterestRate, numYears));//This is my formula for the present value

            return presentValue;//This returns the result of the calculation for the present value
        }
    }
}
